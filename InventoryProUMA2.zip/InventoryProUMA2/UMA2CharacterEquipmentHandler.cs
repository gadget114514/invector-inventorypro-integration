using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System.Collections.Generic;
using Devdog.General.ThirdParty.UniLinq;
using System.Text;
using Devdog.General;
using Devdog.InventoryPro;
using UnityEngine;
using UnityEngine.Assertions;

using UMA.CharacterSystem;
using UMA;

namespace Devdog.InventoryPro
{
    [CreateAssetMenu(menuName = InventoryPro.CreateAssetMenuPath + "UMA2 Character equipment handler")]
    public partial class UMA2CharacterEquipmentHandler : CharacterEquipmentHandler
    {
        /// <summary>
        /// Called when the item is equipped visually / bound to a mesh.
        /// Useful if you wish to remove a custom component whenever the item is equipped.
        /// </summary>
        /// <param name="binder"></param>
        /// <param name="item"></param>
        public delegate void EquippedVisually(CharacterEquipmentTypeBinder binder, EquippableInventoryItem item);
        public event EquippedVisually OnEquippedVisually;
        public event EquippedVisually OnUnEquippedVisually;

        public DynamicCharacterAvatar Avatar;
        public UMATextRecipe Recipe;
        public string Slot;
        public string theText;

        protected UMA2CharacterEquipmentHandler()
        {
            this.characterCollection = characterCollection;
        }

        public void OnEnable()
        {
     //       Debug.Log("enabed charbase");


        }
        public void OnDisable()
        {
   //         Debug.Log("Disabled charbase");
            Avatar = null;

        }
        public void OnDestroy()
        {
            Debug.Log("Destroy charbase");

        }
        public override void SwapItems(ICharacterCollection collection, uint fromSlot, uint toSlot)
        {
            // Items are already swapped here...
            var fromItem = (EquippableInventoryItem)collection.equippableSlots[fromSlot].slot.item;
            var toItem = (EquippableInventoryItem)collection.equippableSlots[toSlot].slot.item;

            UnEquipItemVisually(toItem);

            // Remove from old position
            if (fromItem != null)
            {
                UnEquipItemVisually(fromItem);
            }

            EquipItemVisually(toItem, characterCollection.equippableSlots[toSlot]);

            if (fromItem != null)
            {
                EquipItemVisually(fromItem, characterCollection.equippableSlots[fromSlot]);
            }
        }

        private void NotifyItemEquippedVisually(CharacterEquipmentTypeBinder binder, EquippableInventoryItem item)
        {
            Assert.IsNotNull(item);
            Assert.IsNotNull(binder);

            if (OnEquippedVisually != null)
                OnEquippedVisually(binder, item);

            item.NotifyItemEquippedVisually(binder);

        }

        private void NotifyItemUnEquippedVisually(CharacterEquipmentTypeBinder binder, EquippableInventoryItem item)
        {
            Assert.IsNotNull(item);
            Assert.IsNotNull(binder);

            if (OnUnEquippedVisually != null)
                OnUnEquippedVisually(binder, item);

            item.NotifyItemUnEquippedVisually(binder);

        }

        public override CharacterEquipmentTypeBinder FindEquipmentLocation(EquippableSlot slot)
        {
            foreach (var binder in characterCollection.character.equipmentBinders)
            {
                if (binder.equippableSlot == slot)
                {
                    return binder;
                }
            }

            return null;
        }

        public override void EquipItemVisually(EquippableInventoryItem item)
        {
            var slot = FindEquippableSlotForItem(item);
            EquipItemVisually(item, slot);
        }

        public override void EquipItemVisually(EquippableInventoryItem item, EquippableSlot slot)
        {
            if (item.equipVisually == false)
            {
                return;
            }
            if (Avatar == null)
            {
                this.Avatar = GetCurrentAvatar();
            }
            //TODO      charVisual.EquipItem(item.xeicon);
            AvatarEquipItem(Avatar, item.xetype, item.xename);

            var binder = FindEquipmentLocation(slot);
            if (binder != null)
            {
                var t = GetEquippableTypeFromItem(binder, item);
                item.visuallyEquippedToBinder = binder;
                var copy = t.equipmentHandler.Equip(item, binder, true);

                binder.currentItem = copy.gameObject;
                NotifyItemEquippedVisually(binder, copy);
            }
        }

        public override EquippableSlot FindEquippableSlotForItem(EquippableInventoryItem equippable)
        {
            if (characterCollection.useReferences)
            {
                foreach (var slot in characterCollection.equippableSlots)
                {
                    if (slot.slot.item == equippable)
                    {
                        return characterCollection.equippableSlots[slot.index];
                    }
                }
            }

            return characterCollection.equippableSlots.FirstOrDefault(o => o.equipmentTypes.Contains(equippable.equipmentType));
        }

        private EquipmentType GetEquippableTypeFromItem(CharacterEquipmentTypeBinder binder, EquippableInventoryItem item)
        {
            return binder.equippableSlot.equipmentTypes.FirstOrDefault(o => o == item.equipmentType);
        }

        public override void UnEquipItemVisually(EquippableInventoryItem item)
        {
            if (Avatar == null)
            {
                this.Avatar = GetCurrentAvatar();
            }
            AvatarUnequipItem(Avatar, item.xetype);

            if (item.visuallyEquippedToBinder != null)
            {
                UnEquipItemVisually(item, item.visuallyEquippedToBinder);
            }
        }

        protected virtual void UnEquipItemVisually(EquippableInventoryItem item, CharacterEquipmentTypeBinder binder)
        {
            if (binder != null && binder.currentItem != null)
            {
                var t = GetEquippableTypeFromItem(binder, item);
                t.equipmentHandler.UnEquip(binder, true);
                NotifyItemUnEquippedVisually(binder, item);
            }
        }


        protected DynamicCharacterAvatar GetCurrentAvatar() {
            return GameObject.FindWithTag("Player").GetComponentInChildren<DynamicCharacterAvatar>();  
        }
        protected void AvatarEquipItem(DynamicCharacterAvatar avatar, string slot, string dn)
        {

            if (!Avatar.AvailableRecipes.ContainsKey(slot))
            {
                Debug.LogError("UMA2+IP: unknown slot: " + slot + " " + dn);
                return;
            }
            List<UMATextRecipe> SlotRecipes = Avatar.AvailableRecipes[slot];


            // Find all the wardrobe items for the current slot, and create a button for them.
            UMATextRecipe r = null;
            foreach (UMATextRecipe utr in SlotRecipes)
            {
                string name;
                if (string.IsNullOrEmpty(utr.DisplayValue))
                    name = utr.name;
                else
                    name = utr.DisplayValue;

                if (name == dn) r = utr;
            }

            if (r == null)
            {
                Debug.LogError("UMA2+IP: unknown slot and name: " + slot + " " + dn);
                return;
            }
            Recipe = r;

            // We have a recipe.
            // The wardrobe slot is defined in the recipe itself, so setting a recipe is all 
            // that is needed to "put on" a wardrobe item. 
            // Any recipe that already exists at that slot will be removed - so, for example,
            // putting on a shirt will replace the existing shirt if one exists.
            Avatar.SetSlot(Recipe);
            // Rebuild the character so its wearing the new wardrobe item.
            Avatar.BuildCharacter(true);
            // Avatar.ForceUpdate(true, true, true);
        }
        protected void AvatarUnequipItem(DynamicCharacterAvatar avatar, string Slot)
        {
            Avatar.ClearSlot(Slot);
            Avatar.BuildCharacter(true);
        }
    }
}