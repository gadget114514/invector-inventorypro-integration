using System;
using UnityEngine;
using System.Collections.Generic;
using Devdog.General.ThirdParty.UniLinq;
using System.Reflection;
using Devdog.General;
using Devdog.InventoryPro;
using UnityEngine.Assertions;
using UnityEngine.Serialization;


namespace Devdog.InventoryPro
{
    /// <summary>
    /// Used to represent items that can be equipped by the user, this includes armor, weapons, etc.
    /// </summary>
    public partial class EquippableInventoryItem : InventoryItemBase
    {
        [SerializeField]
        private string _xetype;
        public string xetype
        {
            get { return _xetype; }
            set { _xetype = value; }
        }
        [SerializeField]
        private string _xename;
        public string xename
        {
            get { return _xename; }
            set { _xename = value; }
        }
        [SerializeField]
        private int _xeicon;
        public int xeicon
        {
            get { return _xeicon; }
            set { _xeicon = value; }
        }

        public void SetEquipmentType(EquipmentType etype)
        {
            this.equipmentType = etype;
        }
    }

}